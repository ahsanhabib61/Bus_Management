<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

$bus_no = $_POST['bus_no'];
$seats = $_POST['seats'];
$windowss = $_POST['windowss'];
$bus_time = $_POST['bus_time'];
$route = $_POST['bus_route'];

include "config.php";
$sql = "INSERT INTO buses(id,bus_no, seats, windowss, bus_time, bus_route) VALUES (NULL, '{$bus_no}', '{$seats}', '{$windowss}', '{$bus_time}', '{$route}')";

if(mysqli_query($conn, $sql)){
print( 'Record Inserted');
}
else{
echo 'Not Inserted.';
}
?>

