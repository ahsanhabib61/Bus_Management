<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: PUT');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

$bus_no = $_POST['bus_no'];
$seats = $_POST['seats'];
$windowss = $_POST['windowss'];
$bus_time = $_POST['bus_time'];
$route = $_POST['bus_route'];

include "config.php";
$sql = "UPDATE buses SET bus_no='{$bus_no}', seats='{$seats}', windowss='{$windows}', bus_time='{$bus_time}', bus_route='{$route}' WHERE bus_no='{$bus_no}'";

if(mysqli_query($conn, $sql)){
  echo "Record Updated";
}else{
  echo "Not Updated";
}

?>

