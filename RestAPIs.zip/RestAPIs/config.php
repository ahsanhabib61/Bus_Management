<?php 
$conn = mysqli_connect("localhost","root","","rest_api_data") or die("Connection Failed");
 ?>
