package com.example.busmanagementapp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BusView extends AppCompatActivity {
    TextView FormTextView,TimeTextView,etBusNo,etNoOfSeats,etNoOfWindows,etRoute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bus_view);
        setTitle("BUS MANAGEMENT SYSTEM");
        FormTextView = findViewById(R.id.formTextView);
        TimeTextView = findViewById(R.id.editTextDate);
        etBusNo = findViewById(R.id.spinnerCardType);
        etNoOfSeats = findViewById(R.id.editTextNoOfSeats);
        etNoOfWindows = findViewById(R.id.editTextNoOfWindows);
        etRoute =  findViewById(R.id.editTextRoute);

        etBusNo.setText(getIntent().getStringExtra("BusNo"));
        etNoOfSeats.setText(getIntent().getStringExtra("NoOfSeats"));
        etNoOfWindows.setText(getIntent().getStringExtra("NoOfWindows"));
        TimeTextView.setText(getIntent().getStringExtra("DepTime"));
        etRoute.setText(getIntent().getStringExtra("Route"));

    }
}

