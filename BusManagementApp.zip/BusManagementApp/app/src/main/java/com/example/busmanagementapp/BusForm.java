package com.example.busmanagementapp;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;


public class BusForm extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    public String sBusNo,sNoOfSeats,sNoOfWindows,sTime,sRoute;
    Button addBtn,deleteBtn,updateBtn;
    TextView FormTextView;
    EditText etBusNo,etNoOfSeats,etNoOfWindows,etID;
    Spinner spinnerRoute;
    int hour,min;
    String valueFromSpinnerRoute;
    BusDBHelper busDBHelper = new BusDBHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bus_form);
        setTitle("BUS MANAGEMENT SYSTEM");
        FormTextView = findViewById(R.id.formTextView);
        spinnerRoute = findViewById(R.id.spinnerRoute);
        etBusNo = findViewById(R.id.spinnerCardType);
        etNoOfSeats = findViewById(R.id.editTextNoOfSeats);
        etNoOfWindows = findViewById(R.id.editTextNoOfWindows);
        etID =findViewById(R.id.editTextID);
        addBtn = findViewById(R.id.addBtn1);
        deleteBtn = findViewById(R.id.deleteBtn1);
        updateBtn = findViewById(R.id.updateBtn1);

        spinnerRoute.setOnItemSelectedListener(this);
        String[] routeNames = getResources().getStringArray(R.array.routeNames);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,routeNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRoute.setAdapter(adapter);


        TimePicker picker=(TimePicker)findViewById(R.id.timePicker1);
        picker.setIs24HourView(true);

        final Calendar calendar = Calendar.getInstance();

        addBtn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                hour = picker.getHour();
                min = picker.getMinute();
                sTime = hour+" : "+min;
                sBusNo = etBusNo.getText().toString();
                sNoOfSeats = etNoOfSeats.getText().toString();
                sNoOfWindows = etNoOfWindows.getText().toString();
                sRoute = valueFromSpinnerRoute;

                boolean flag = busDBHelper.insertData(sBusNo,sNoOfSeats,sNoOfWindows,sTime,sRoute);
                if(flag == true)
                    Toast.makeText(BusForm.this,"Data Inserted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(BusForm.this,"Not Inserted",Toast.LENGTH_LONG).show();
                Intent obj =new Intent();
                finish();

            }
        });
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int delRows;
                delRows = busDBHelper.deleteData(etID.getText().toString());
                if(delRows > 0)
                    Toast.makeText(BusForm.this,"Data Deleted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(BusForm.this,"Not Deleted",Toast.LENGTH_LONG).show();
                finish();
            }
        });
        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean flag = busDBHelper.updateData( etID.getText().toString(), etBusNo.getText().toString(), etNoOfSeats.getText().toString(), etNoOfWindows.getText().toString(), hour+" : "+min,valueFromSpinnerRoute);
                if(flag == true)
                    Toast.makeText(BusForm.this,"Data Updated",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(BusForm.this,"Not Updated",Toast.LENGTH_LONG).show();
                finish();
            }
        });


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(parent.getId()==R.id.spinnerRoute){
            valueFromSpinnerRoute = parent.getItemAtPosition(position).toString();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}




