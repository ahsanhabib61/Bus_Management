package com.example.busmanagementapp;

public class BusList {


    private  String ID;
    private String BusNo;
    private String NoOfSeats;
    private String NoOfWindows;
    private String DepTime;



    private String Route;

    public BusList(String ID, String busNo, String noOfSeats, String noOfWindows, String depTime, String route) {
        this.ID = ID;
        BusNo = busNo;
        NoOfSeats = noOfSeats;
        NoOfWindows = noOfWindows;
        DepTime = depTime;
        Route =  route;
    }



    public BusList(String items) {
        String[] singleItem = items.split(",");

        if(singleItem.length>4){
            ID = singleItem[0];
            BusNo = singleItem[1];
            NoOfSeats = singleItem[2];
            NoOfWindows = singleItem[3];
            DepTime = singleItem[4];
            Route = singleItem[5];
        }
    }



    public String getID() { return ID;  }
    public void setID(String ID) { this.ID = ID; }

    public String getBusNo() {
        return BusNo;
    }

    public void setBusNo(String busNo) {
        BusNo = busNo;
    }

    public String getNoOfSeats() {
        return NoOfSeats;
    }

    public void setNoOfSeats(String noOfSeats) {
        NoOfSeats = noOfSeats;
    }

    public String getNoOfWindows() {
        return NoOfWindows;
    }

    public void setNoOfWindows(String noOfWindows) {
        NoOfWindows = noOfWindows;
    }

    public String getDepTime() {
        return DepTime;
    }

    public void setDepTime(String depTime) {
        DepTime = depTime;
    }
    public String getRoute() {
        return Route;
    }

    public void setRoute(String route) {
        Route = route;
    }

    @Override
    public String toString() {
        return "MyList{" +
                "ID='" + ID + '\'' +
                ", BusNo='" + BusNo + '\'' +
                ", NoOfSeats='" + NoOfSeats + '\'' +
                ", NoOfWindows='" + NoOfWindows + '\'' +
                ", DepTime='" + DepTime + '\'' +
                ", Route='" + Route + '\'' +
                '}';
    }
}


