package com.example.busmanagementapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignUP extends AppCompatActivity {
    TextView textView;
    EditText username, password, rePassword;
    Button regBtn;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        textView = findViewById(R.id.alreadyacc);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignUP.this, Login.class));
            }
        });
        username = (EditText) findViewById(R.id.inputUsername);
        password = (EditText) findViewById(R.id.inputPassword);
        rePassword = (EditText) findViewById(R.id.inputConfirmPass);
        regBtn = (Button) findViewById(R.id.regBtn);
        DB = new DBHelper(this);
        regBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = rePassword.getText().toString();
                if(user.equals("") || pass.equals("")|| repass.equals("")){
                    Toast.makeText(SignUP.this,
                            "please enter all the field", Toast.LENGTH_SHORT).show();

                }
                else{
                    if(pass.equals(repass)){
                        boolean checkuser = DB.checkUsername(user);
                        if(!checkuser){
                            boolean insert = DB.insertData(user, pass);
                            if(insert){
                                Toast.makeText(SignUP.this,
                                        "Registered Successfully", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                            else{
                                Toast.makeText(SignUP.this,
                                        "Registered Failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(SignUP.this,
                                    "User Already Exists", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(SignUP.this, "Password incorrect", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}
