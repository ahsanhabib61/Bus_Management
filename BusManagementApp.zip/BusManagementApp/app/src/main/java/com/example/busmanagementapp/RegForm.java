package com.example.busmanagementapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegForm extends AppCompatActivity {
    public String sFullName,sMobileNo,sEmail,sPassword,sAddress;
    Button addBtn,deleteBtn,updateBtn;
    TextView FormTextView;
    EditText etFullName,etMobileNo,etEmail,etPassword,etAddress,etID;
    RegDBHelper regDBHelper = new RegDBHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reg_form);
        setTitle("BUS MANAGEMENT SYSTEM");
        FormTextView = findViewById(R.id.formTextView);
        etFullName = findViewById(R.id.spinnerCardType);
        etMobileNo = findViewById(R.id.editTextNoOfSeats);
        etEmail = findViewById(R.id.editTextNoOfWindows);
        etPassword = findViewById(R.id.editTextDate);
        etAddress = findViewById(R.id.editTextAddress);
        etID =findViewById(R.id.editTextID);
        addBtn = findViewById(R.id.addBtn1);
        deleteBtn = findViewById(R.id.deleteBtn1);
        updateBtn = findViewById(R.id.updateBtn1);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sFullName = etFullName.getText().toString();
                sMobileNo = etMobileNo.getText().toString();
                sEmail = etEmail.getText().toString();
                sPassword = etPassword.getText().toString();
                sAddress = etAddress.getText().toString();
                boolean flag = regDBHelper.insertData(sFullName,sMobileNo,sEmail,sPassword,sAddress);
                if(flag == true)
                    Toast.makeText(RegForm.this,"Data Inserted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(RegForm.this,"Not Inserted",Toast.LENGTH_LONG).show();
                finish();

            }
        });
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int delRows = regDBHelper.deleteData(etID.getText().toString());
                if(delRows > 0)
                    Toast.makeText(RegForm.this,"Data Deleted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(RegForm.this,"Not Deleted",Toast.LENGTH_LONG).show();
                finish();
            }
        });
        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean flag = regDBHelper.updateData( etID.getText().toString(), etFullName.getText().toString(), etMobileNo.getText().toString(), etEmail.getText().toString(), etPassword.getText().toString(),etAddress.getText().toString()  );
                if(flag == true)
                    Toast.makeText(RegForm.this,"Data Updated",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(RegForm.this,"Not Updated",Toast.LENGTH_LONG).show();
                finish();
            }
        });


    }

   /* @Override
    protected void onPause() {
        super.onPause();

        String data;
        data = sFullName+","+sMobileNo+","+sEmail+","+sPassword+","+sAddress;
        File dir = Environment.getExternalStorageDirectory();
        File mydatadir = new File(dir,"/MyData");
        if(!mydatadir.exists())
        {
            mydatadir.mkdir();
        }

        File myFile = new File(mydatadir,"myFile.txt");
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(myFile,true);

            fos.write(data.toString().getBytes());
            fos.write(new String("\n").getBytes());
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/
}


