package com.example.busmanagementapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    TextView textView;
    EditText username, password;
    Button btnLogin;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        textView = findViewById(R.id.signup);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Login.this, SignUP.class));
            }
        });
        username = (EditText) findViewById(R.id.inputUsername);
        password = (EditText) findViewById(R.id.inputEmail);
        btnLogin = (Button) findViewById(R.id.loginbtn);
        DB = new DBHelper(this);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                if(user.equals("")||pass.equals("")){
                    Toast.makeText(Login.this,
                            "Please enter all fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    boolean checkUsernamePass = DB.checkUsernamePass(user, pass);
                    if(checkUsernamePass){
                        Intent intent = new Intent(Login.this,MainActivity.class);
                        startActivity(intent);
                        Toast.makeText(Login.this,
                                "SignIn Successfully", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(Login.this,
                                "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}