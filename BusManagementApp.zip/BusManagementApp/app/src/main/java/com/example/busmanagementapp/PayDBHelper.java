package com.example.busmanagementapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;


public class PayDBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "BusManagementAppDB.db";
//    public static final String DATABASE_NAME = "PaymentDB.db";
    public static final String PAYMENT_TABLE_NAME = "payment";
    public static final String PAYMENT_COLUMN_ID = "id";
    public static final String PAYMENT_COLUMN_CARD = "card";
    public static final String PAYMENT_COLUMN_CVV = "cvv";
    public static final String PAYMENT_COLUMN_AMOUNT = "amount";
    public static final String PAYMENT_COLUMN_DATE = "date";
    private HashMap hp;

    public PayDBHelper(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL("create table " +PAYMENT_TABLE_NAME+
                "(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                "card TEXT NOT NULL ," +
                "cvv INTEGER NOT NULL, " +
                "amount TEXT NOT NULL," +
                "date varchar(200) NOT NULL)" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS " + PAYMENT_TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData (String card, String cvv, String amount, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("card", card);
        contentValues.put("cvv", cvv);
        contentValues.put("amount", amount);
        contentValues.put("date", date);
        db.insert(PAYMENT_TABLE_NAME, null, contentValues);
        return true;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from payment where id="+id+"", null );
        return res;
    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, PAYMENT_TABLE_NAME);
        return numRows;
    }

    public boolean updateData (String id, String card, String cvv, String amount, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("card", card);
        contentValues.put("cvv", cvv);
        contentValues.put("amount", amount);
        contentValues.put("date", date);
        db.update(PAYMENT_TABLE_NAME, contentValues, "id = ? ", new String[] { id } );
        return true;
    }

    public Integer deleteData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(PAYMENT_TABLE_NAME,
                "id = ? ",
                new String[] { id });
    }

    public ArrayList<String> getAllData() {
        ArrayList<String> array_list = new ArrayList<String>();
        ArrayList<String> idList = new ArrayList<>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from payment", null );
        res.moveToFirst();

        while(res.isAfterLast() == false){
            // array_list.add(res.getString(res.getColumnIndex(PAYMENT_COLUMN_NAME)));
            array_list.add(res.getString(res.getColumnIndex(PAYMENT_COLUMN_ID))+","+res.getString(res.getColumnIndex(PAYMENT_COLUMN_CARD))+","+res.getString(res.getColumnIndex(PAYMENT_COLUMN_CVV))+","+res.getString(res.getColumnIndex(PAYMENT_COLUMN_AMOUNT))+","+res.getString(res.getColumnIndex(PAYMENT_COLUMN_DATE)));
            idList.add(res.getString(res.getColumnIndex(PAYMENT_COLUMN_ID)));
            res.moveToNext();
        }
        Log.i("dbData2",idList.toString());
        return array_list;
    }

}




