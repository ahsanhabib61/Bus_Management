package com.example.busmanagementapp;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class PayAdapter extends BaseAdapter {

    List<PayList> ListItems;
    Context context;

    public PayAdapter(List<PayList> listItems, Context context)
    {
        this.ListItems = listItems;
        this.context = context;
    }
    @Override
    public int getCount() {
        return ListItems.size();
    }

    @Override
    public Object getItem(int position) {
        return ListItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.pay_listview, parent, false);
        ((TextView) view.findViewById(R.id.IdTv)).setText(ListItems.get(position).getID());
        ((TextView) view.findViewById(R.id.BusNoTv)).setText(ListItems.get(position).getCVV());
        ((TextView) view.findViewById(R.id.TimwTv)).setText(ListItems.get(position).getAmount());
        view.findViewById(R.id.ListViewBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("listt","data"+ListItems.get(position).getCVV());
                Intent intent = new Intent(context,PayView.class);
                intent.setFlags(intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("CardType", ListItems.get(position).getCardType());
                intent.putExtra("CVV", ListItems.get(position).getCVV());
                intent.putExtra("Amount", ListItems.get(position).getAmount());
                intent.putExtra("Date", ListItems.get(position).getDueDate());
                context.startActivity(intent);
            }
        });
        return view;
    }
}

