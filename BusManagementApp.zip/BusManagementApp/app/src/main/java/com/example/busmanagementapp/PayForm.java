package com.example.busmanagementapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class PayForm extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    public String sCardType,sCVV,sAmount,sDate;
    Button addBtn,deleteBtn,updateBtn;
    TextView FormTextView,DateTextView;
    EditText etCVV,etAmount,etID;
    Spinner spinnerCardType;
    int year, day, month;
    String valueFromSpinnerCardTypes;
    PayDBHelper payDBHelper = new PayDBHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pay_form);
        setTitle("BUS MANAGEMENT SYSTEM");
        FormTextView = findViewById(R.id.formTextView);
        DateTextView = findViewById(R.id.textViewTime);
        spinnerCardType = findViewById(R.id.spinnerCardType);
        etCVV = findViewById(R.id.editTextNoOfSeats);
        etAmount = findViewById(R.id.editTextNoOfWindows);
        etID =findViewById(R.id.editTextID);
        addBtn = findViewById(R.id.addBtn1);
        deleteBtn = findViewById(R.id.deleteBtn1);
        updateBtn = findViewById(R.id.updateBtn1);
        spinnerCardType.setOnItemSelectedListener(this);
        String[] cardTypes = getResources().getStringArray(R.array.cardTypes);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,cardTypes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCardType.setAdapter(adapter);


        final Calendar calendar = Calendar.getInstance();

        DateTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                day = calendar.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog dpd = new DatePickerDialog(PayForm.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                        DateTextView.setText(dayOfMonth + "-" + month + "-" + year);
                    }
                }, year, month, day);
                dpd.show();
            }
        });

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sCardType = valueFromSpinnerCardTypes;
                sCVV = etCVV.getText().toString();
                sAmount = etAmount.getText().toString();
                sDate = DateTextView.getText().toString();

                boolean flag = payDBHelper.insertData(sCardType,sCVV,sAmount,sDate);
                if(flag == true)
                    Toast.makeText(PayForm.this,"Data Inserted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(PayForm.this,"Not Inserted",Toast.LENGTH_LONG).show();
                Intent obj =new Intent();
                finish();

            }
        });
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int delRows;
                delRows = payDBHelper.deleteData(etID.getText().toString());
                if(delRows > 0)
                    Toast.makeText(PayForm.this,"Data Deleted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(PayForm.this,"Not Deleted",Toast.LENGTH_LONG).show();
                finish();
            }
        });
        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean flag = payDBHelper.updateData( etID.getText().toString(), valueFromSpinnerCardTypes, etCVV.getText().toString(), etAmount.getText().toString(), DateTextView.getText().toString());
                if(flag == true)
                    Toast.makeText(PayForm.this,"Data Updated",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(PayForm.this,"Not Updated",Toast.LENGTH_LONG).show();
                finish();
            }
        });


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(parent.getId()==R.id.spinnerCardType){
            valueFromSpinnerCardTypes = parent.getItemAtPosition(position).toString();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}



