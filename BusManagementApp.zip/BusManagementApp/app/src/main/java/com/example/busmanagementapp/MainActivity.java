package com.example.busmanagementapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    CardView registerCard,paymentCard,busCard,routeCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        registerCard =  findViewById(R.id.registerCard);
        paymentCard =  findViewById(R.id.paymentCard);
        busCard =  findViewById(R.id.busCard);
        routeCard =  findViewById(R.id.routeCard);
        
        registerCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast("Card Clicked");
                Intent intent = new Intent(MainActivity.this,Register.class);
                startActivity(intent);

            }
        });

        paymentCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast("Card Clicked");
                Intent intent = new Intent(MainActivity.this,Payment.class);
                startActivity(intent);

            }
        });

        busCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast("Card Clicked");
                Intent intent = new Intent(MainActivity.this,Bus.class);
                startActivity(intent);

            }
        });

    }
    private void showToast(String txt){
        Toast.makeText(MainActivity.this,txt,Toast.LENGTH_LONG).show();
    }
}