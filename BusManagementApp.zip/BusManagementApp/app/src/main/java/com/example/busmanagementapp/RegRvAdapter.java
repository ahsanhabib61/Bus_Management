package com.example.busmanagementapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class RegRvAdapter extends RecyclerView.Adapter<RegRvAdapter.RvHolder>{

    List<RegList> ListItems;
    Context context;

    public RegRvAdapter(List<RegList> listItems, Context context) {
        ListItems = listItems;
        this.context = context;
    }

    @NonNull
    @Override
    public RvHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.reg_listview, parent, false);
        RvHolder rvHolder = new RvHolder(view);
        return rvHolder;
    }


    @Override
    public void onBindViewHolder(@NonNull  RegRvAdapter.RvHolder holder, int position) {
        holder.IDTextView.setText(ListItems.get(position).getID());
        holder.listTextView.setText(ListItems.get(position).getFullName());
        holder.listBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context,RegView.class);
                intent.putExtra("FullName", ListItems.get(position).getFullName());
                intent.putExtra("MobileNo", ListItems.get(position).getMobileNo());
                intent.putExtra("Email", ListItems.get(position).getEmail());
                intent.putExtra("Password", ListItems.get(position).getPassword());
                intent.putExtra("Address", ListItems.get(position).getAddress());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return ListItems.size();
    }

    public static class RvHolder extends RecyclerView.ViewHolder {
        public TextView listTextView,IDTextView;
        public Button listBtn;
        public RvHolder(@NonNull  View itemView) {
            super(itemView);
            IDTextView = (TextView) itemView.findViewById(R.id.IdTv);
            listTextView = (TextView) itemView.findViewById(R.id.BusNoTv);
            listBtn = (Button) itemView.findViewById(R.id.ListViewBtn);
        }
    }
}

