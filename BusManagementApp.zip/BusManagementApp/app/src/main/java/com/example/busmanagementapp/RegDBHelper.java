package com.example.busmanagementapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;

public class RegDBHelper extends SQLiteOpenHelper {

//    public static final String DATABASE_NAME = "BusManagementAppDB.db";
    public static final String DATABASE_NAME = "RegistrationDB.db";
    public static final String REGISTRATION_TABLE_NAME = "registration";
    public static final String REGISTRATION_COLUMN_ID = "id";
    public static final String REGISTRATION_COLUMN_NAME = "name";
    public static final String REGISTRATION_COLUMN_PHONE = "phone";
    public static final String REGISTRATION_COLUMN_EMAIL = "email";
    public static final String REGISTRATION_COLUMN_PASSWORD = "password";
    public static final String REGISTRATION_COLUMN_ADDRESS = "address";
    private HashMap hp;

    public RegDBHelper(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL("create table " +REGISTRATION_TABLE_NAME+
                "(ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                "name TEXT NOT NULL ," +
                "phone TEXT NOT NULL, " +
                "email TEXT NOT NULL," +
                "password TEXT NOT NULL, " +
                "address TEXT NOT NULL)" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS " + REGISTRATION_TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData (String name, String phone, String email, String password,String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("phone", phone);
        contentValues.put("email", email);
        contentValues.put("password", password);
        contentValues.put("address", address);
        db.insert(REGISTRATION_TABLE_NAME, null, contentValues);
        return true;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from registration where id="+id+"", null );
        return res;
    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, REGISTRATION_TABLE_NAME);
        return numRows;
    }

    public boolean updateData (String id, String name, String phone, String email, String password,String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("phone", phone);
        contentValues.put("email", email);
        contentValues.put("password", password);
        contentValues.put("address", address);
        db.update(REGISTRATION_TABLE_NAME, contentValues, "id = ? ", new String[] { id } );
        return true;
    }

    public Integer deleteData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(REGISTRATION_TABLE_NAME,
                "id = ? ",
                new String[] { id });
    }

    public ArrayList<String> getAllNames() {
        ArrayList<String> array_list = new ArrayList<String>();
        ArrayList<String> idList = new ArrayList<>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from registration", null );
        res.moveToFirst();
        res.moveToFirst();

        while(res.isAfterLast() == false){
            // array_list.add(res.getString(res.getColumnIndex(REGISTRATION_COLUMN_NAME)));
            array_list.add(res.getString(res.getColumnIndex(REGISTRATION_COLUMN_ID))+","+res.getString(res.getColumnIndex(REGISTRATION_COLUMN_NAME))+","+res.getString(res.getColumnIndex(REGISTRATION_COLUMN_PHONE))+","+res.getString(res.getColumnIndex(REGISTRATION_COLUMN_EMAIL))+","+res.getString(res.getColumnIndex(REGISTRATION_COLUMN_PASSWORD))+","+res.getString(res.getColumnIndex(REGISTRATION_COLUMN_ADDRESS)));
            idList.add(res.getString(res.getColumnIndex(REGISTRATION_COLUMN_ID)));
            res.moveToNext();
        }
        Log.i("dbData",idList.toString());
        return array_list;
    }
   /* public List<MyList> getData(){
        List<MyList> ListItems = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from registration", null );
        res.moveToFirst();

        while(res.isAfterLast() == false){
            ListItems.add(new MyList(res.getString(res.getColumnIndex(REGISTRATION_COLUMN_NAME)),res.getString(res.getColumnIndex(REGISTRATION_COLUMN_PHONE)),res.getString(res.getColumnIndex(REGISTRATION_COLUMN_EMAIL)),res.getString(res.getColumnIndex(REGISTRATION_COLUMN_PASSWORD)),res.getString(res.getColumnIndex(REGISTRATION_COLUMN_ADDRESS))));
           // array_list.add(res.getString(res.getColumnIndex(REGISTRATION_COLUMN_NAME)));
            res.moveToNext();
        }
        return ListItems;
    }*/
}

