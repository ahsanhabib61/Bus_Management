package com.example.busmanagementapp;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class BusAdapter extends BaseAdapter {

    List<BusList> ListItems;
    Context context;

    public BusAdapter(List<BusList> listItems, Context context)
    {
        this.ListItems = listItems;
        this.context = context;
    }
    @Override
    public int getCount() {
        return ListItems.size();
    }

    @Override
    public Object getItem(int position) {
        return ListItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.bus_listview, parent, false);
        ((TextView) view.findViewById(R.id.IdTv)).setText(ListItems.get(position).getID());
        ((TextView) view.findViewById(R.id.BusNoTv)).setText(ListItems.get(position).getBusNo());
        ((TextView) view.findViewById(R.id.TimwTv)).setText(ListItems.get(position).getDepTime());
        view.findViewById(R.id.ListViewBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("listt","data"+ListItems.get(position).getBusNo());
                Intent intent = new Intent(context,BusView.class);
                intent.setFlags(intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("BusNo", ListItems.get(position).getBusNo());
                intent.putExtra("NoOfSeats", ListItems.get(position).getNoOfSeats());
                intent.putExtra("NoOfWindows", ListItems.get(position).getNoOfWindows());
                intent.putExtra("DepTime", ListItems.get(position).getDepTime());
                intent.putExtra("Route", ListItems.get(position).getRoute());
                context.startActivity(intent);
            }
        });
        return view;
    }
}

