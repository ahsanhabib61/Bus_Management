package com.example.busmanagementapp;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class RegAdapter extends BaseAdapter {

    List<RegList> ListItems;
    Context context;

    public RegAdapter(List<RegList> listItems, Context context)
    {
        this.ListItems = listItems;
        this.context = context;
    }
    @Override
    public int getCount() {
        return ListItems.size();
    }

    @Override
    public Object getItem(int position) {
        return ListItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.reg_listview, parent, false);
        ((TextView) view.findViewById(R.id.IdTv)).setText(ListItems.get(position).getID());
        ((TextView) view.findViewById(R.id.BusNoTv)).setText(ListItems.get(position).getFullName());
        view.findViewById(R.id.ListViewBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("listt","data"+ListItems.get(position).getFullName());
                Intent intent = new Intent(context,RegView.class);
                intent.setFlags(intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("FullName", ListItems.get(position).getFullName());
                intent.putExtra("MobileNo", ListItems.get(position).getMobileNo());
                intent.putExtra("Email", ListItems.get(position).getEmail());
                intent.putExtra("Password", ListItems.get(position).getPassword());
                intent.putExtra("Address", ListItems.get(position).getAddress());
                context.startActivity(intent);
            }
        });
        return view;
    }
}
