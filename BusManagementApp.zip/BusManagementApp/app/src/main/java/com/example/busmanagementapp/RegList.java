package com.example.busmanagementapp;

public class RegList {


    private  String ID;
    private String FullName;
    private String MobileNo;
    private String Email;
    private String Password;
    private String Address;

    public RegList(String id, String fullName, String mobileNo, String email, String password, String address) {
        ID = id;
        FullName = fullName;
        MobileNo = mobileNo;
        Email = email;
        Password = password;
        Address = address;
    }



    public RegList(String items) {
        String[] singleItem = items.split(",");

        if(singleItem.length>5){
            ID = singleItem[0];
            FullName = singleItem[1];
            MobileNo = singleItem[2];
            Email = singleItem[3];
            Password = singleItem[4];
            Address = singleItem[5];
        }
    }

    public String getID() { return ID;  }
    public void setID(String ID) { this.ID = ID; }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String fullName) {
        FullName = fullName;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public void setMobileNo(String mobileNo) {
        MobileNo = mobileNo;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    @Override
    public String toString() {
        return "MyList{" +
                "ID='" + ID + '\'' +
                ", FullName='" + FullName + '\'' +
                ", MobileNo='" + MobileNo + '\'' +
                ", Email='" + Email + '\'' +
                ", Password='" + Password + '\'' +
                ", Address='" + Address + '\'' +
                '}';
    }
}

