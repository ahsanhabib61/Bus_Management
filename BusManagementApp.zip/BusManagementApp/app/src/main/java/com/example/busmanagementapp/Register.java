package com.example.busmanagementapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class Register extends AppCompatActivity {

    TextView RPTextView,IDTextView,ListTextView;
    Button RegBtn;
    ListView myLv;
//    RecyclerView myRv;
//    RecyclerView.LayoutManager layoutManager;
    public String sFullName,sMobileNo,sEmail,sPassword,sAddress;
    List<RegList> ListItems = new ArrayList<>();
    RegAdapter regAdapter;
    //String[] dataItems;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onStart() {
        super.onStart();
        setContentView(R.layout.activity_register);
        setTitle("BUS MANAGEMENT SYSTEM");
        RPTextView =  findViewById(R.id.rpTextView);
        IDTextView = findViewById(R.id.IdTv);
        ListTextView = findViewById(R.id.BusNoTv);
        RegBtn = findViewById(R.id.myBtn);
        myLv   = findViewById(R.id.myList);
        Log.i("word","working fine");

        ListItems.clear();
        regAdapter =  new RegAdapter(ListItems,getApplicationContext());
        myLv.setAdapter(regAdapter);

//        layoutManager = new LinearLayoutManager(this);
//        myRv.setLayoutManager(layoutManager);
//        RegRvAdapter regRvAdapter =  new RegRvAdapter(ListItems,getApplicationContext() );
//        myRv.setAdapter(regRvAdapter);
        regAdapter.notifyDataSetChanged();

        RegDBHelper regDBHelper = new RegDBHelper(Register.this);
        ArrayList<String> names = regDBHelper.getAllNames();
        //regDBHelper.deleteData(6);
        for(String str: names){
            ListItems.add(new RegList(str));
            Log.i("testItems","Items : "+str);
        }
        regAdapter.notifyDataSetChanged();
        for(RegList items: ListItems){
            Log.i("sample","items :"+items);
        }


        /*File dir = Environment.getExternalStorageDirectory();
        File mydatadir = new File(dir,"/MyData");
        if(!mydatadir.exists())
        {
            mydatadir.mkdir();
        }

        File myFile = new File(mydatadir,"myFile.txt");
        try
        {
            FileReader fr=new FileReader(myFile);   //reads the file
            BufferedReader br=new BufferedReader(fr);  //creates a buffering character input stream
            StringBuffer sb=new StringBuffer();    //constructs a string buffer with no characters
            String line;
            while((line=br.readLine())!=null)
            {
                sb.append(line);      //appends line to string buffer
                sb.append("\n");     //line feed
            }
            String strBufferData = sb.toString();
            fr.close();    //closes the stream and release the resources
            String[] dataItems = strBufferData.split("\n");
            Log.i("xtr",Arrays.toString(dataItems));
            for(String items : dataItems){
                ListItems.add(new MyList(items));
            }

            myAdapter.notifyDataSetChanged();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }*/


        RegBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Register.this,RegForm.class);
                startActivityForResult(intent,001);
                Toast.makeText(Register.this, "Button click", Toast.LENGTH_SHORT).show();
            }
        });
    }

}

