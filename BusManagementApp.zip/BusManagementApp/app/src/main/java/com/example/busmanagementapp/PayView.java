package com.example.busmanagementapp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PayView extends AppCompatActivity {
    TextView FormTextView,DateTextView,etCardType,etCVV,etAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pay_view);
        setTitle("BUS MANAGEMENT SYSTEM");
        FormTextView = findViewById(R.id.formTextView);
        DateTextView = findViewById(R.id.editTextDate);
        etCardType = findViewById(R.id.spinnerCardType);
        etCVV = findViewById(R.id.editTextNoOfSeats);
        etAmount= findViewById(R.id.editTextNoOfWindows);

        etCardType.setText(getIntent().getStringExtra("CardType"));
        etCVV.setText(getIntent().getStringExtra("CVV"));
        etAmount.setText(getIntent().getStringExtra("Amount"));
        DateTextView.setText(getIntent().getStringExtra("Date"));

    }
}
