package com.example.busmanagementapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;

public class BusDBHelper extends SQLiteOpenHelper {


    public static final String DATABASE_NAME = "BussDB.db";
    public static final String BUS_TABLE_NAME = "bus";
    public static final String BUS_COLUMN_ID = "id";
    public static final String BUS_COLUMN_NO = "busNo";
    public static final String BUS_COLUMN_SEATS = "seats";
    public static final String BUS_COLUMN_WINDOWS = "windows";
    public static final String BUS_COLUMN_TIME = "time";
    public static final String BUS_COLUMN_ROUTE = "route";
    private HashMap hp;

    public BusDBHelper(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL("create table " +BUS_TABLE_NAME+
                "(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                "busNo INTEGER NOT NULL ," +
                "seats INTEGER NOT NULL, " +
                "windows INTEGER NOT NULL," +
                "time varchar(100) NOT NULL," +
                "route TEXT NOT NULL)" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS " + BUS_TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData (String busNo, String seats, String windows, String time, String route) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("busNo", busNo);
        contentValues.put("seats", seats);
        contentValues.put("windows", windows);
        contentValues.put("time", time);
        contentValues.put("route", route);
        db.insert(BUS_TABLE_NAME, null, contentValues);
        return true;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from bus where id="+id+"", null );
        return res;
    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, BUS_TABLE_NAME);
        return numRows;
    }

    public boolean updateData (String id, String busNo, String seats, String windows, String time, String route) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("busNo", busNo);
        contentValues.put("seats", seats);
        contentValues.put("windows", windows);
        contentValues.put("time", time);
        contentValues.put("route", route);
        db.update(BUS_TABLE_NAME, contentValues, "id = ? ", new String[] { id } );
        return true;
    }

    public Integer deleteData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(BUS_TABLE_NAME,
                "id = ? ",
                new String[] { id });
    }

    public ArrayList<String> getAllData() {
        ArrayList<String> array_list = new ArrayList<String>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from BUS", null );
        res.moveToFirst();

        while(res.isAfterLast() == false){
            // array_list.add(res.getString(res.getColumnIndex(BUS_COLUMN_NAME)));
            array_list.add(res.getString(res.getColumnIndex(BUS_COLUMN_ID))+","+res.getString(res.getColumnIndex(BUS_COLUMN_NO))+","+res.getString(res.getColumnIndex(BUS_COLUMN_SEATS))+","+res.getString(res.getColumnIndex(BUS_COLUMN_WINDOWS))+","+res.getString(res.getColumnIndex(BUS_COLUMN_TIME))+","+res.getString(res.getColumnIndex(BUS_COLUMN_ROUTE)));
            res.moveToNext();
        }
        Log.i("dbData3",array_list.toString());
        return array_list;
    }

}




