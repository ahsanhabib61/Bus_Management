package com.example.busmanagementapp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class RegView extends AppCompatActivity {
    public String sFullName,sMobileNo,sEmail,sPassword,sAddress;
    TextView FormTextView;
    TextView etFullName,etMobileNo,etEmail,etPassword,etAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reg_view);
        setTitle("BUS MANAGEMENT SYSTEM");
        FormTextView = findViewById(R.id.formTextView);
        etFullName = findViewById(R.id.spinnerCardType);
        etMobileNo = findViewById(R.id.editTextNoOfSeats);
        etEmail = findViewById(R.id.editTextNoOfWindows);
        etPassword = findViewById(R.id.editTextDate);
        etAddress = findViewById(R.id.editTextAddress);
        etFullName.setText(getIntent().getStringExtra("FullName"));
        etMobileNo.setText(getIntent().getStringExtra("MobileNo"));
        etEmail.setText(getIntent().getStringExtra("Email"));
        etPassword.setText(getIntent().getStringExtra("Password"));
        etAddress.setText(getIntent().getStringExtra("Address"));

    }
}
