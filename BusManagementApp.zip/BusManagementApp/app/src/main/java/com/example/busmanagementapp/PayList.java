package com.example.busmanagementapp;


public class PayList {


    private  String ID;
    private String CardType;
    private String CVV;
    private String Amount;
    private String DueDate;


    public PayList(String id, String cardType, String cvv, String amount, String dueDate) {
        ID = id;
        CardType = cardType;
        CVV = cvv;
        Amount = amount;
        DueDate = dueDate;
    }



    public PayList(String items) {
        String[] singleItem = items.split(",");

        if(singleItem.length>4){
            ID = singleItem[0];
            CardType = singleItem[1];
            CVV = singleItem[2];
            Amount = singleItem[3];
            DueDate = singleItem[4];
        }
    }

    public String getID() { return ID;  }
    public void setID(String ID) { this.ID = ID; }

    public String getCardType() {
        return CardType;
    }

    public void setCardType(String cardType) {
        CardType = cardType;
    }

    public String getCVV() {
        return CVV;
    }

    public void setCVV(String cvv) {
        CVV = cvv;
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String amount) {
        Amount = amount;
    }

    public String getDueDate() {
        return DueDate;
    }

    public void setDueDate(String dueDate) {
        DueDate = dueDate;
    }

    @Override
    public String toString() {
        return "MyList{" +
                "ID='" + ID + '\'' +
                ", CardType='" + CardType + '\'' +
                ", CVV='" + CVV + '\'' +
                ", Amount='" + Amount + '\'' +
                ", DueDate='" + DueDate + '\'' +
                '}';
    }
}


