package com.example.busmanagementapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class Payment extends AppCompatActivity {

    TextView RPTextView,IdTextView,CvvTextView,AmountTextView;
    Button RegBtn;
    ListView myLv;
    //    RecyclerView myRv;
//    RecyclerView.LayoutManager layoutManager;
    public String sFullName,sMobileNo,sEmail,sPassword,sAddress;
    List<PayList> ListItems = new ArrayList<>();
    PayAdapter payAdapter;
    //String[] dataItems;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onStart() {
        super.onStart();
        setContentView(R.layout.activity_payment);
        setTitle("BUS MANAGEMENT SYSTEM");
        RPTextView =  findViewById(R.id.rpTextView);
        IdTextView =  findViewById(R.id.IdTv);
        CvvTextView =  findViewById(R.id.BusNoTv);
        AmountTextView =  findViewById(R.id.TimwTv);
        RegBtn = findViewById(R.id.myBtn);
        myLv   = findViewById(R.id.myList);
        Log.i("word","working fine");

        ListItems.clear();
        payAdapter =  new PayAdapter(ListItems,getApplicationContext());
        myLv.setAdapter(payAdapter);

//        layoutManager = new LinearLayoutManager(this);
//        myRv.setLayoutManager(layoutManager);
//        RegRvAdapter regRvAdapter =  new RegRvAdapter(ListItems,getApplicationContext() );
//        myRv.setAdapter(regRvAdapter);
        payAdapter.notifyDataSetChanged();

        PayDBHelper payDBHelper = new PayDBHelper(Payment.this);
        ArrayList<String> names = payDBHelper.getAllData();
        //regDBHelper.deleteData(6);
        for(String str: names){
            ListItems.add(new PayList(str));
            Log.i("testItems","Items : "+str);
        }
        payAdapter.notifyDataSetChanged();
        for(PayList items: ListItems){
            Log.i("sample","items :"+items);
        }


        /*File dir = Environment.getExternalStorageDirectory();
        File mydatadir = new File(dir,"/MyData");
        if(!mydatadir.exists())
        {
            mydatadir.mkdir();
        }

        File myFile = new File(mydatadir,"myFile.txt");
        try
        {
            FileReader fr=new FileReader(myFile);   //reads the file
            BufferedReader br=new BufferedReader(fr);  //creates a buffering character input stream
            StringBuffer sb=new StringBuffer();    //constructs a string buffer with no characters
            String line;
            while((line=br.readLine())!=null)
            {
                sb.append(line);      //appends line to string buffer
                sb.append("\n");     //line feed
            }
            String strBufferData = sb.toString();
            fr.close();    //closes the stream and release the resources
            String[] dataItems = strBufferData.split("\n");
            Log.i("xtr",Arrays.toString(dataItems));
            for(String items : dataItems){
                ListItems.add(new MyList(items));
            }

            myAdapter.notifyDataSetChanged();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }*/


        RegBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Payment.this,PayForm.class);
                startActivityForResult(intent,001);
                Toast.makeText(Payment.this, "Button click", Toast.LENGTH_SHORT).show();
            }
        });
    }

}

